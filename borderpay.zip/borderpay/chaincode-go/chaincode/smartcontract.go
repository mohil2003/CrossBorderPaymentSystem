package chaincode

import (
	"encoding/json"
	"fmt"
	"log"
	"time"
	"hash/fnv"
	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)
const employeeCollection = "employeeCollection"
const employerCollection = "employerCollection"
const contractCollection = "contractCollection"
const transactionCollection = "transactionCollection"
const bankaccountCollection = "bankaccountCollection"
const routingbankCollection = "routingbankCollection"
const centralbankCollection = "centralbankCollection"
const pendingtransactions="pendingtransactions"
const AgreedContractCollection="AgreedContractCollection"
const FinishedContractCollection="FinishedContractCollection"
// SmartContract provides functions for managing an Asset
type SmartContract struct {
	contractapi.Contract
}

// Asset describes basic details of what makes up a simple asset
// Insert struct field in alphabetic order => to achieve determinism across languages
// golang keeps the order when marshal to json but doesn't order automatically
type Employee struct {
    Name string    `json:"Name"`
	Password string `json:"password"`
    ID          string `json:"employee_ID"`
	Bankid string `json:"bankid"`
}
type Contract struct {
    Employee_ID string    `json:"Employee_id"`
	Contract_ID string    `json:"Contract_ID"`
    Employer_ID string    `json:"Employer_id"`
    CTC_salary int `json:"CTC_salary"`
    Basic_salary int `json:"Basic_salary"`
    Contract_period int `json:"Contract_period"`
	Salary_period int `json:"salary_period"`
}
type Employer struct {
    Name string    `json:"Name"`
	Password string `json:"password"`
    ID          string `json:"employee_ID"`
	Bankid string `json:"bankid"`
}
type Bank_Account struct {
    Name string    `json:"Name"`
    Account_ID          string `json:"Account_ID"`
    Bank_ID         string `json:"bankid"`
    Balance             int `json:"Balance"`
}
type Routing_Bank struct {
    Name string    `json:"Name"`
    Bank_ID          string `json:"Bank_ID"`
	Password string `json:"password"`
    Central_bank_ID       string    `json:"Central_bank"`
    Balance             int `json:"Balance"`
    Currency         string `json:"Currency"`
}
type Central_Bank struct {
    Name string    `json:"Name"`
    Bank_ID          string `json:"Bank_ID"`
	Password string `json:"password"`
    Balance             int `json:"Balance"`
    Currency         string `json:"Currency"`
	Country string `json:"Country"`
}
// type Forex_Bank struct {
//     Exchange_rates    []int `json:"Exchange_Rate"`
// }
type Transaction struct {
    Transaction_ID string    `json:"Transaction_ID"`
    Sender_ID string    `json:"Sender_ID"`
    Reciever_ID string    `json:"Reciever_ID"`
    Amount int    `json:"Amount"`
	Contract_id string `json:"contract_id"`
    Exchange_rate int `json:"exchange_rate"`
    Date string `json:"date"`
	Status string `json:"status"`
}
func (s *SmartContract) CentralBankAsset(ctx contractapi.TransactionContextInterface, name string, password string,id string,balance int ,currency string,country string) error {
	var centralbank = Central_Bank{
		Name:             name,
		Password:           password,
		Bank_ID:      id,
		Balance: balance,
		Currency:currency,
		Country:country,
	}
	centralbankJSON, err := json.Marshal(centralbank)
	if err != nil {
		return fmt.Errorf("failed to marshal centralbank into JSON: %v", err)
	}
	assetAsBytes, err := ctx.GetStub().GetPrivateData(centralbankCollection, id)
	if err != nil {
		return fmt.Errorf("failed to get centralbank: %v", err)
	} else if assetAsBytes != nil {
		fmt.Println("centralbank already exists: " + id)
		return fmt.Errorf("this centralbank already exists: " + id)
	}

	if err != nil {
		return fmt.Errorf("centralbankAsset cannot be performed: Error %v", err)
	}
	log.Printf("centralbankAsset Put: collection %v, ID %v", centralbankCollection, id)

	err = ctx.GetStub().PutPrivateData(centralbankCollection, id, centralbankJSON)
	if err != nil {
		return fmt.Errorf("failed to put asset into private data collecton: %v", err)
	}
	return nil
}

func (s *SmartContract) RoutingBankAsset(ctx contractapi.TransactionContextInterface, name string, password string,id string,balance int ,currency string,central_bank_id string) error {
	var routingbank = Routing_Bank{
		Name:             name,
		Password:           password,
		Bank_ID:      id,
		Balance: balance,
		Currency:currency,
		Central_bank_ID:central_bank_id,
	}
	routingbankJSON, err := json.Marshal(routingbank)
	if err != nil {
		return fmt.Errorf("failed to marshal routingbank into JSON: %v", err)
	}
	assetAsBytes, err := ctx.GetStub().GetPrivateData(routingbankCollection, id)
	if err != nil {
		return fmt.Errorf("failed to get routingbank: %v", err)
	} else if assetAsBytes != nil {
		fmt.Println("routingbank already exists: " + id)
		return fmt.Errorf("this routingbank already exists: " + id)
	}

	if err != nil {
		return fmt.Errorf("routingbankAsset cannot be performed: Error %v", err)
	}
	log.Printf("routingbankAsset Put: collection %v, ID %v", routingbankCollection, id)

	err = ctx.GetStub().PutPrivateData(routingbankCollection, id, routingbankJSON)
	if err != nil {
		return fmt.Errorf("failed to put asset into private data collecton: %v", err)
	}
	return nil
}
func (s *SmartContract) BankAccountAsset(ctx contractapi.TransactionContextInterface, id string, name string,bankid string,balance int ) error {
	var bankaccount = Bank_Account{
		Account_ID:             id,
		Name:           name,
		Bank_ID:      bankid,
		Balance: balance,
	}
	bankaccountJSON, err := json.Marshal(bankaccount)
	if err != nil {
		return fmt.Errorf("failed to marshal bankaccount into JSON: %v", err)
	}
	assetAsBytes, err := ctx.GetStub().GetPrivateData(bankaccountCollection, id)
	if err != nil {
		return fmt.Errorf("failed to get bankaccount: %v", err)
	} else if assetAsBytes != nil {
		fmt.Println("bankaccount already exists: " + id)
		return fmt.Errorf("this bankaccount already exists: " + id)
	}

	if err != nil {
		return fmt.Errorf("bankaccountAsset cannot be performed: Error %v", err)
	}
	log.Printf("bankaccountAsset Put: collection %v, ID %v", bankaccountCollection, id)

	err = ctx.GetStub().PutPrivateData(bankaccountCollection, id, bankaccountJSON)
	if err != nil {
		return fmt.Errorf("failed to put asset into private data collecton: %v", err)
	}
	return nil
}
func (s *SmartContract) TransactionAsset(ctx contractapi.TransactionContextInterface, trans_id string, send_id string, reciev_id string,amount int,contract_id string,exchange_rates int, date string,status string) error {
	var transaction = Transaction{
		Transaction_ID:             trans_id,
		Sender_ID:           send_id,
		Contract_id: 	 contract_id,
		Reciever_ID:      reciev_id,
		Exchange_rate: exchange_rates,
		Amount:amount,
		Date:date,
		Status:status,
	}
	transactionJSON, err := json.Marshal(transaction)
	if err != nil {
		return fmt.Errorf("failed to marshal transaction into JSON: %v", err)
	}
	assetAsBytes, err := ctx.GetStub().GetPrivateData(transactionCollection, trans_id)
	if err != nil {
		return fmt.Errorf("failed to get transaction: %v", err)
	} else if assetAsBytes != nil {
		fmt.Println("transaction already exists: " + trans_id)
		return fmt.Errorf("this transaction already exists: " + trans_id)
	}

	if err != nil {
		return fmt.Errorf("transactionAssest cannot be performed: Error %v", err)
	}
	log.Printf("ContractAsset Put: collection %v, ID %v", transactionCollection, trans_id)

	err = ctx.GetStub().PutPrivateData(transactionCollection, trans_id, transactionJSON)
	if err != nil {
		return fmt.Errorf("failed to put asset into private data collecton: %v", err)
	}
	return nil
}
func (s *SmartContract) AssetExists(ctx contractapi.TransactionContextInterface, id string) (bool, error) {
	assetJSON, err := ctx.GetStub().GetState(id)
	if err != nil {
		return false, fmt.Errorf("failed to read from world state: %v", err)
	}

	return assetJSON != nil, nil
}
func (s *SmartContract) ContractAsset(ctx contractapi.TransactionContextInterface, emp_id string, cont_id string, emplyr_id string,ctc_salary int,salary_period int,contract_period int, basic_salary int) error {
	var contract = Contract{
		Employee_ID:             emp_id,
		Employer_ID:           emplyr_id,
		Contract_ID: 	 cont_id,
		CTC_salary:      ctc_salary,
		Salary_period: salary_period,
		Contract_period:contract_period,
		Basic_salary:basic_salary,
	}
	contractJSON, err := json.Marshal(contract)
	if err != nil {
		return fmt.Errorf("failed to marshal contract into JSON: %v", err)
	}
	assetAsBytes, err := ctx.GetStub().GetPrivateData(contractCollection, cont_id)
	if err != nil {
		return fmt.Errorf("failed to get contract: %v", err)
	} else if assetAsBytes != nil {
		fmt.Println("contract already exists: " + cont_id)
		return fmt.Errorf("this contract already exists: " + cont_id)
	}

	if err != nil {
		return fmt.Errorf("contractAssest cannot be performed: Error %v", err)
	}
	log.Printf("ContractAsset Put: collection %v, ID %v", contractCollection, cont_id)

	err = ctx.GetStub().PutPrivateData(contractCollection, cont_id, contractJSON)
	if err != nil {
		return fmt.Errorf("failed to put asset into private data collecton: %v", err)
	}
	return nil
}
func (s *SmartContract) EmployeeAsset(ctx contractapi.TransactionContextInterface, id string, name string, password string,bankid string,balance int ) error {
	var employee = Employee{
		ID:             id,
		Name:           name,
		Password: 	 password,
		Bankid:      bankid,
	}
	employeeJSON, err := json.Marshal(employee)
	if err != nil {
		return fmt.Errorf("failed to marshal employee into JSON: %v", err)
	}
	assetAsBytes, err := ctx.GetStub().GetPrivateData(employeeCollection, id)
	if err != nil {
		return fmt.Errorf("failed to get employee: %v", err)
	} else if assetAsBytes != nil {
		fmt.Println("Employee already exists: " + id)
		return fmt.Errorf("this employee already exists: " + id)
	}

	if err != nil {
		return fmt.Errorf("EmployeeAsset cannot be performed: Error %v", err)
	}
	log.Printf("EmployeeAsset Put: collection %v, ID %v", employeeCollection, id)

	err = ctx.GetStub().PutPrivateData(employeeCollection, id, employeeJSON)
	if err != nil {
		return fmt.Errorf("failed to put asset into private data collecton: %v", err)
	}
	return nil
}
func (s *SmartContract) EmployerAsset(ctx contractapi.TransactionContextInterface, id string, name string, password string,bankid string,balance int ) error {
	var employer = Employer{
		ID:             id,
		Name:           name,
		Password: 	 password,
		Bankid:      bankid,
	}
	employerJSON, err := json.Marshal(employer)
	if err != nil {
		return fmt.Errorf("failed to marshal employer into JSON: %v", err)
	}
	assetAsBytes, err := ctx.GetStub().GetPrivateData(employerCollection, id)
	if err != nil {
		return fmt.Errorf("failed to get employer: %v", err)
	} else if assetAsBytes != nil {
		fmt.Println("Employer already exists: " + id)
		return fmt.Errorf("this employer already exists: " + id)
	}

	if err != nil {
		return fmt.Errorf("EmployerAsset cannot be performed: Error %v", err)
	}
	log.Printf("EmployerAsset Put: collection %v, ID %v", employerCollection, id)

	err = ctx.GetStub().PutPrivateData(employerCollection, id, employerJSON)
	if err != nil {
		return fmt.Errorf("failed to put asset into private data collecton: %v", err)
	}
	return nil
}
func (s *SmartContract) AgreedContracts(ctx contractapi.TransactionContextInterface, contractID string) error {
	assetAsBytes, err := ctx.GetStub().GetPrivateData(contractCollection, contractID)
	if err != nil {
		return fmt.Errorf("failed to get asset: %v", err)
	}
	if assetAsBytes == nil {
		fmt.Println("Contract does not exist: " + contractID)
		return fmt.Errorf("Contract does not exist: " + contractID)
	}
	contract := Contract{}
	err = json.Unmarshal(assetAsBytes, &contract)
	if err != nil {
		return fmt.Errorf("failed to unmarshal JSON: %v", err)
	}

	assetJSONasBytes, err := json.Marshal(contract)
	if err != nil {
		return fmt.Errorf("failed to marshal asset into JSON: %v", err)
	}

	err = ctx.GetStub().DelPrivateData(contractCollection, contractID)
	if err != nil {
		return fmt.Errorf("failed to delete contract from private data collection: %v", err)
	}

	log.Printf("AgreeToContract Put: collection %v, ID %v", AgreedContractCollection, contractID)
	err = ctx.GetStub().PutPrivateData(AgreedContractCollection, contractID, assetJSONasBytes)
	if err != nil {
		return fmt.Errorf("failed to put asset into private data collecton: %v", err)
	}
	return nil
}
func (s *SmartContract) FinshedContracts(ctx contractapi.TransactionContextInterface, contractID string) error {
	assetAsBytes, err := ctx.GetStub().GetPrivateData(contractCollection, contractID)
	if err != nil {
		return fmt.Errorf("failed to get asset: %v", err)
	}
	if assetAsBytes == nil {
		fmt.Println("Contract does not exist: " + contractID)
		return fmt.Errorf("Contract does not exist: " + contractID)
	}
	contract := Contract{}
	err = json.Unmarshal(assetAsBytes, &contract)
	if err != nil {
		return fmt.Errorf("failed to unmarshal JSON: %v", err)
	}

	assetJSONasBytes, err := json.Marshal(contract)
	if err != nil {
		return fmt.Errorf("failed to marshal asset into JSON: %v", err)
	}

	err = ctx.GetStub().DelPrivateData(contractCollection, contractID)
	if err != nil {
		return fmt.Errorf("failed to delete contract from private data collection: %v", err)
	}

	log.Printf("FinishedContract Put: collection %v, ID %v", FinishedContractCollection, contractID)
	err = ctx.GetStub().PutPrivateData(FinishedContractCollection, contractID, assetJSONasBytes)
	if err != nil {
		return fmt.Errorf("failed to put asset into private data collecton: %v", err)
	}
	return nil
}
func (s *SmartContract) GetEmployer(ctx contractapi.TransactionContextInterface, ID string) (*Employer, error) {

	log.Printf("ReadAsset: collection %v, ID %v", employerCollection, ID)
	employerJSON, err := ctx.GetStub().GetPrivateData(employerCollection, ID) //get the asset from chaincode state
	if err != nil {
		return nil, fmt.Errorf("failed to read asset: %v", err)
	}

	// No Asset found, return empty response
	if employerJSON == nil {
		log.Printf("%v does not exist in collection %v", ID, employerCollection)
		return nil, nil
	}

	var emp *Employer
	err = json.Unmarshal(employerJSON, &emp)
	if err != nil {
		return nil, fmt.Errorf("failed to unmarshal JSON: %v", err)
	}

	return emp, nil
}
func (s *SmartContract) GetEmployee(ctx contractapi.TransactionContextInterface, ID string) (*Employee, error) {

	log.Printf("ReadAsset: collection %v, ID %v", employeeCollection, ID)
	employeeJSON, err := ctx.GetStub().GetPrivateData(employeeCollection, ID) //get the asset from chaincode state
	if err != nil {
		return nil, fmt.Errorf("failed to read asset: %v", err)
	}

	// No Asset found, return empty response
	if employeeJSON == nil {
		log.Printf("%v does not exist in collection %v", ID, employeeCollection)
		return nil, nil
	}

	var emp *Employee
	err = json.Unmarshal(employeeJSON, &emp)
	if err != nil {
		return nil, fmt.Errorf("failed to unmarshal JSON: %v", err)
	}

	return emp, nil
}
func (s *SmartContract) GetContractsForEmployer(ctx contractapi.TransactionContextInterface, ID string) ([]*Contract, error) {

	queryString := fmt.Sprintf("{\"selector\":{\"EmployerID\":\"%v\"}}", ID)

	queryResults, err := s.getQueryResultForQueryString(ctx, queryString)
	if err != nil {
		return nil, err
	}
	return queryResults, nil
}
func (s *SmartContract) GetContractsForEmployee(ctx contractapi.TransactionContextInterface, ID string) ([]*Contract, error) {

	queryString := fmt.Sprintf("{\"selector\":{\"EmployeeID\":\"%v\"}}", ID)

	queryResults, err := s.getQueryResultForQueryString(ctx, queryString)
	if err != nil {
		return nil, err
	}
	return queryResults, nil
}
func (s *SmartContract) getQueryResultForQueryString(ctx contractapi.TransactionContextInterface, queryString string) ([]*Contract, error) {

	resultsIterator, err := ctx.GetStub().GetPrivateDataQueryResult(AgreedContractCollection, queryString)
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()

	results := []*Contract{}

	for resultsIterator.HasNext() {
		response, err := resultsIterator.Next()
		if err != nil {
			return nil, err
		}
		var asset *Contract

		err = json.Unmarshal(response.Value, &asset)
		if err != nil {
			return nil, fmt.Errorf("failed to unmarshal JSON: %v", err)
		}

		results = append(results, asset)
	}
	return results, nil
}
func (s *SmartContract) BanktoBank(ctx contractapi.TransactionContextInterface, accountID1 string,accountID2 string,bankID1 string,BankID2 string,amount int,contract_id string )(*Transaction, error) {
	log.Printf("ReadAsset: collection %v, ID %v", bankaccountCollection, accountID1)
	accountJSON, err := ctx.GetStub().GetPrivateData(bankaccountCollection, accountID1) //get the asset from chaincode state
	if err != nil {
		return  nil,fmt.Errorf("failed to read asset: %v", err)
	}

	// No Asset found, return empty response
	if accountJSON == nil {
		log.Printf("%v does not exist in collection %v", bankID1, bankaccountCollection)
		return  nil,nil
	}

	var acc_1 *Bank_Account
	err = json.Unmarshal(accountJSON, &acc_1)
	if err != nil {
		return nil,fmt.Errorf("failed to unmarshal JSON: %v", err)
	}

	log.Printf("ReadAsset: collection %v, ID %v", bankaccountCollection, accountID2)
	accountJSON2, err := ctx.GetStub().GetPrivateData(bankaccountCollection, accountID2) //get the asset from chaincode state
	if err != nil {
		return nil,fmt.Errorf("failed to read asset: %v", err)
	}

	// No Asset found, return empty response
	if accountJSON2 == nil {
		log.Printf("%v does not exist in collection %v", accountID2, bankaccountCollection)
		return nil,nil
	}

	var acc_2 *Bank_Account
	err = json.Unmarshal(accountJSON2, &acc_2)
	if err != nil {
		return nil,fmt.Errorf("failed to unmarshal JSON: %v", err)
	}

	acc_1.Balance += amount
	accountJSON, err = json.Marshal(acc_1)
	if err != nil {
		return nil,fmt.Errorf("failed to marshal account JSON: %v", err)
	}

	err = ctx.GetStub().PutState(accountID1, accountJSON)
	if err != nil {
		return nil,fmt.Errorf("failed to put account state: %v", err)
	}
	acc_2.Balance-=amount
	accountJSON, err = json.Marshal(acc_2)
	if err != nil {
		return nil,fmt.Errorf("failed to marshal account JSON: %v", err)
	}

	err = ctx.GetStub().PutPrivateData(bankaccountCollection, BankID2, accountJSON)
	if err != nil {
		return nil,fmt.Errorf("failed to put account state: %v", err)
	}

	var transaction = Transaction{
		Transaction_ID:            newTansaction(),
		Sender_ID:           accountID1,
		Contract_id: 	 contract_id,
		Reciever_ID:      accountID2,
		Exchange_rate: 1,
		Amount:acc_2.Balance,
		Date:time.Now().String(),
		Status:"Completed",
	}
	transactionJSON, err := json.Marshal(transaction)
	if err != nil {
		return nil,fmt.Errorf("failed to marshal transaction into JSON: %v", err)
	}
	assetAsBytes, err := ctx.GetStub().GetPrivateData(transactionCollection, transaction.Transaction_ID)
	if err != nil {
		return nil,fmt.Errorf("failed to get transaction: %v", err)
	} else if assetAsBytes != nil {
		fmt.Println("transaction already exists: " + transaction.Transaction_ID)
		return nil,fmt.Errorf("this transaction already exists: " + transaction.Transaction_ID)
	}

	if err != nil {
		return nil,fmt.Errorf("transactionAssest cannot be performed: Error %v", err)
	}
	log.Printf("ContractAsset Put: collection %v, ID %v", transactionCollection, transaction.Transaction_ID)

	err = ctx.GetStub().PutPrivateData(transactionCollection, transaction.Transaction_ID, transactionJSON)
	if err != nil {
		return nil,fmt.Errorf("failed to put asset into private data collecton: %v", err)
	}
	var trans *Transaction
	err = json.Unmarshal(transactionJSON, &trans)
	if err != nil {
		return nil,fmt.Errorf("failed to unmarshal JSON: %v", err)
	}
	return trans,nil
}
func (s *SmartContract) BanktoCentralBank(ctx contractapi.TransactionContextInterface, bankID1 string,BankID2 string,amount int,exchange_rate int)(*Transaction, error) {
	log.Printf("ReadAsset: collection %v, ID %v", routingbankCollection, bankID1)
	accountJSON, err := ctx.GetStub().GetPrivateData(routingbankCollection, bankID1) //get the asset from chaincode state
	if err != nil {
		return  nil,fmt.Errorf("failed to read asset: %v", err)
	}

	// No Asset found, return empty response
	if accountJSON == nil {
		log.Printf("%v does not exist in collection %v", bankID1, routingbankCollection)
		return  nil,nil
	}

	var acc_1 *Routing_Bank
	err = json.Unmarshal(accountJSON, &acc_1)
	if err != nil {
		return nil,fmt.Errorf("failed to unmarshal JSON: %v", err)
	}

	log.Printf("ReadAsset: collection %v, ID %v", centralbankCollection, BankID2)
	accountJSON2, err := ctx.GetStub().GetPrivateData(centralbankCollection, BankID2) //get the asset from chaincode state
	if err != nil {
		return nil,fmt.Errorf("failed to read asset: %v", err)
	}

	// No Asset found, return empty response
	if accountJSON2 == nil {
		log.Printf("%v does not exist in collection %v", BankID2, centralbankCollection)
		return nil,nil
	}

	var acc_2 *Central_Bank
	err = json.Unmarshal(accountJSON2, &acc_2)
	if err != nil {
		return nil,fmt.Errorf("failed to unmarshal JSON: %v", err)
	}

	acc_1.Balance += amount*exchange_rate
	accountJSON, err = json.Marshal(acc_1)
	if err != nil {
		return nil,fmt.Errorf("failed to marshal account JSON: %v", err)
	}

	err = ctx.GetStub().PutState(bankID1, accountJSON)
	if err != nil {
		return nil,fmt.Errorf("failed to put account state: %v", err)
	}
	acc_2.Balance-=amount
	accountJSON, err = json.Marshal(acc_2)
	if err != nil {
		return nil,fmt.Errorf("failed to marshal account JSON: %v", err)
	}

	err = ctx.GetStub().PutPrivateData(centralbankCollection, BankID2, accountJSON)
	if err != nil {
		return nil,fmt.Errorf("failed to put account state: %v", err)
	}

	var transaction = Transaction{
		Transaction_ID:            newTansaction(),
		Sender_ID:           bankID1,
		Contract_id: 	 "",
		Reciever_ID:      BankID2,
		Exchange_rate: exchange_rate,
		Amount:acc_2.Balance,
		Date:time.Now().String(),
		Status:"Bank_to_CentralBank",
	}
	transactionJSON, err := json.Marshal(transaction)
	if err != nil {
		return nil,fmt.Errorf("failed to marshal transaction into JSON: %v", err)
	}
	assetAsBytes, err := ctx.GetStub().GetPrivateData(pendingtransactions, transaction.Transaction_ID)
	if err != nil {
		return nil,fmt.Errorf("failed to get transaction: %v", err)
	} else if assetAsBytes != nil {
		fmt.Println("transaction already exists: " + transaction.Transaction_ID)
		return nil,fmt.Errorf("this transaction already exists: " + transaction.Transaction_ID)
	}

	if err != nil {
		return nil,fmt.Errorf("transactionAssest cannot be performed: Error %v", err)
	}
	log.Printf("ContractAsset Put: collection %v, ID %v", pendingtransactions, transaction.Transaction_ID)

	err = ctx.GetStub().PutPrivateData(pendingtransactions, transaction.Transaction_ID, transactionJSON)
	if err != nil {
		return nil,fmt.Errorf("failed to put asset into private data collecton: %v", err)
	}
	var trans *Transaction
	err = json.Unmarshal(transactionJSON, &trans)
	if err != nil {
		return nil,fmt.Errorf("failed to unmarshal JSON: %v", err)
	}
	return trans,nil
}
func (s *SmartContract) CentralBanktoBank(ctx contractapi.TransactionContextInterface, bankID1 string,BankID2 string,amount int,exchange_rate int)(*Transaction, error) {
	log.Printf("ReadAsset: collection %v, ID %v", centralbankCollection, bankID1)
	accountJSON, err := ctx.GetStub().GetPrivateData(centralbankCollection, bankID1) //get the asset from chaincode state
	if err != nil {
		return  nil,fmt.Errorf("failed to read asset: %v", err)
	}

	// No Asset found, return empty response
	if accountJSON == nil {
		log.Printf("%v does not exist in collection %v", bankID1, centralbankCollection)
		return  nil,nil
	}

	var acc_1 *Central_Bank
	err = json.Unmarshal(accountJSON, &acc_1)
	if err != nil {
		return nil,fmt.Errorf("failed to unmarshal JSON: %v", err)
	}

	log.Printf("ReadAsset: collection %v, ID %v", routingbankCollection, BankID2)
	accountJSON2, err := ctx.GetStub().GetPrivateData(routingbankCollection, BankID2) //get the asset from chaincode state
	if err != nil {
		return nil,fmt.Errorf("failed to read asset: %v", err)
	}

	// No Asset found, return empty response
	if accountJSON2 == nil {
		log.Printf("%v does not exist in collection %v", BankID2, routingbankCollection)
		return nil,nil
	}

	var acc_2 *Central_Bank
	err = json.Unmarshal(accountJSON2, &acc_2)
	if err != nil {
		return nil,fmt.Errorf("failed to unmarshal JSON: %v", err)
	}

	acc_1.Balance += amount
	accountJSON, err = json.Marshal(acc_1)
	if err != nil {
		return nil,fmt.Errorf("failed to marshal account JSON: %v", err)
	}

	err = ctx.GetStub().PutState(bankID1, accountJSON)
	if err != nil {
		return nil,fmt.Errorf("failed to put account state: %v", err)
	}
	acc_2.Balance-=amount*exchange_rate
	accountJSON, err = json.Marshal(acc_2)
	if err != nil {
		return nil,fmt.Errorf("failed to marshal account JSON: %v", err)
	}

	err = ctx.GetStub().PutPrivateData(routingbankCollection, BankID2, accountJSON)
	if err != nil {
		return nil,fmt.Errorf("failed to put account state: %v", err)
	}

	var transaction = Transaction{
		Transaction_ID:            newTansaction(),
		Sender_ID:           bankID1,
		Contract_id: 	 "",
		Reciever_ID:      BankID2,
		Exchange_rate: exchange_rate,
		Amount:acc_2.Balance,
		Date:time.Now().String(),
		Status:"CentralBank_to_Bank",
	}
	transactionJSON, err := json.Marshal(transaction)
	if err != nil {
		return nil,fmt.Errorf("failed to marshal transaction into JSON: %v", err)
	}
	assetAsBytes, err := ctx.GetStub().GetPrivateData(pendingtransactions, transaction.Transaction_ID)
	if err != nil {
		return nil,fmt.Errorf("failed to get transaction: %v", err)
	} else if assetAsBytes != nil {
		fmt.Println("transaction already exists: " + transaction.Transaction_ID)
		return nil,fmt.Errorf("this transaction already exists: " + transaction.Transaction_ID)
	}

	if err != nil {
		return nil,fmt.Errorf("transactionAssest cannot be performed: Error %v", err)
	}
	log.Printf("ContractAsset Put: collection %v, ID %v", pendingtransactions, transaction.Transaction_ID)

	err = ctx.GetStub().PutPrivateData(pendingtransactions, transaction.Transaction_ID, transactionJSON)
	if err != nil {
		return nil,fmt.Errorf("failed to put asset into private data collecton: %v", err)
	}
	var trans *Transaction
	err = json.Unmarshal(transactionJSON, &trans)
	if err != nil {
		return nil,fmt.Errorf("failed to unmarshal JSON: %v", err)
	}
	return trans,nil
}
func (s *SmartContract) GetBankAccount(ctx contractapi.TransactionContextInterface, ID string) (*Bank_Account, error) {

	log.Printf("ReadAsset: collection %v, ID %v", bankaccountCollection, ID)
	bankaccountJSON, err := ctx.GetStub().GetPrivateData(bankaccountCollection, ID) //get the asset from chaincode state
	if err != nil {
		return nil, fmt.Errorf("failed to read asset: %v", err)
	}

	// No Asset found, return empty response
	if bankaccountJSON == nil {
		log.Printf("%v does not exist in collection %v", ID, bankaccountCollection)
		return nil, nil
	}

	var acc *Bank_Account
	err = json.Unmarshal(bankaccountJSON, &acc)
	if err != nil {
		return nil, fmt.Errorf("failed to unmarshal JSON: %v", err)
	}

	return acc, nil
}

func newTansaction() string {
	h := fnv.New32a()
	h.Write([]byte(time.Now().String()))
	return fmt.Sprintf("%d",h.Sum32())
}

func (s *SmartContract) QueryTransactionByEmployer(ctx contractapi.TransactionContextInterface, employer string) ([]*Transaction, error) {

	queryString := fmt.Sprintf("{\"selector\":{\"EmployerID\":\"%v\"}}", employer)

	queryResults1, err := s.getQueryResultForQueryStringFortransactions(ctx, queryString)
	if err != nil {
		return nil, err
	}
	return queryResults1, nil
}
func (s *SmartContract) QueryTransactionByEmployee(ctx contractapi.TransactionContextInterface, employee string) ([]*Transaction, error) {

	queryString := fmt.Sprintf("{\"selector\":{\"EmployeeID\":\"%v\"}}", employee)

	queryResults2, err := s.getQueryResultForQueryStringFortransactions(ctx, queryString)
	if err != nil {
		return nil, err
	}
	return queryResults2, nil
}

func (s *SmartContract) getQueryResultForQueryStringFortransactions(ctx contractapi.TransactionContextInterface, queryString string) ([]*Transaction, error) {
	resultsIterator, err := ctx.GetStub().GetPrivateDataQueryResult(pendingtransactions, queryString)
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()
	results := []*Transaction{}
	for resultsIterator.HasNext() {
		response, err := resultsIterator.Next()
		if err != nil {
			return nil, err
		}
		var asset *Transaction
		err = json.Unmarshal(response.Value, &asset)
		if err != nil {
			return nil, fmt.Errorf("failed to unmarshal JSON: %v", err)
		}
		results = append(results, asset)
	}
	return results, nil
}